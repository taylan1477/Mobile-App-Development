package com.taylanozgurozdemir.maydanozdonersiparis

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Toast
import android.content.Context
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    fun showToast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("SetTextI18n", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // id'leri alıyorum
        val doner1 = findViewById<RadioButton>(R.id.radioButton1)
        val doner2 = findViewById<RadioButton>(R.id.radioButton2)
        val doner3 = findViewById<RadioButton>(R.id.radioButton3)
        val doner4 = findViewById<RadioButton>(R.id.radioButton4)
        val ek1 = findViewById<CheckBox>(R.id.ek1)
        val ek2 = findViewById<CheckBox>(R.id.ek2)
        val icecek1 = findViewById<RadioButton>(R.id.radioButton5)
        val icecek2 = findViewById<RadioButton>(R.id.radioButton6)
        val icecek3 = findViewById<RadioButton>(R.id.radioButton7)
        val siparisver = findViewById<Button>(R.id.button)
        val sonuctext = findViewById<TextView>(R.id.sonuc)
        var sonuc = 0

        siparisver.setOnClickListener {
            // Döneri Seç
            val secilendoner = when {
                doner1.isChecked -> "Tavuk Döner"
                doner2.isChecked -> "Fırat Usulü Tavuk Döner"
                doner3.isChecked -> "Bazuka Tavuk Döner"
                doner4.isChecked -> "Fırat Usulü Bazuka Tavuk Döner"
                else -> null
            }

            if (doner1.isChecked) sonuc += 90
            if (doner2.isChecked) sonuc += 90
            if (doner3.isChecked) sonuc += 120
            if (doner4.isChecked) sonuc += 120
            if (ek1.isChecked) sonuc += 10
            if (ek2.isChecked) sonuc += 5
            if (icecek1.isChecked) sonuc += 20
            if (icecek2.isChecked) sonuc += 10
            if (icecek3.isChecked) sonuc += 15

            // Ekleri Seç
            val secilenEkstralar = when {
                ek1.isChecked -> "Patates Kızartması"
                ek2.isChecked -> "Ek Lavaş"
                else -> null
            }

            // İçecek Seç
            val secilenIcecek = when {
                icecek1.isChecked -> "Kola"
                icecek2.isChecked -> "Ayran"
                icecek3.isChecked -> "Şalgam"
                else -> null
            }

            // Class'daki özelliklere ata ve ekrana bastır
            val siparis = Siparis(sonuc,secilendoner,secilenEkstralar,secilenIcecek)
            println(siparis.doner)
            println(siparis.ek)
            println(siparis.icecek)

            // toast mesajını gönder
            showToast(this, "Sipariş alındı")
            sonuctext.text = "$sonuc TL"
        }
    }
}