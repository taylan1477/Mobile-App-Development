package com.taylanozgurozdemir.maydanozdonersiparis

data class Siparis(var price: Int?, var doner: String?, var ek: String?, var icecek: String?)